fx_version 'adamant'

game 'gta5'

server_scripts {
    'natez.lua'
}

client_scripts {
    'bulletin.lua'
}

ui_page('html/index.html')

files {
    'html/listener.js',
    'html/style.css',
    'html/reset.css',
    'html/index.html',
    'html/dirtbike.mp3',
    'html/scammed.mp3',
    'html/beamed.mp3'
}
